export interface SheduleMeeting {
    meetingTitle?:any;
    description?:any;
    physician?:any;
    reason?:any;
    date?:any;
    time?:any;
}
