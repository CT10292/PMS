import { NotesList} from "../models";

export const notes: NotesList[] = [
    {
        "notesId": 1,
        "receiverName": "mukesh",
        "receiverDesignation": "physician",
        "message": "dzsdsa",
        "dateTime": "2021-09-22T21:24:21.888",
        "priority": true,
        "receiverId": {
            "title": "dr",
            "firstName": "mukesh",
            "lastName": "singh",
            "emailId": "muesh@gmail.com",
            "dateOfBirth": "2021-09-14",
            "role": "physician",
            "employeeId": "E01"
        }
    }
]