package com.citiustech.pms.community.model;

public class ReportPost {

}
