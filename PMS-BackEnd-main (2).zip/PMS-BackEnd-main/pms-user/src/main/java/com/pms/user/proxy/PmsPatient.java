//package com.pms.user.proxy;
//
//import java.util.List;
//
//import org.springframework.cloud.openfeign.FeignClient;
//import org.springframework.web.bind.annotation.GetMapping;
//
//import com.pms.user.entity.PatientData;
//
//@FeignClient(name = "pms-patient")
//public interface PmsPatient {
//	
//	@GetMapping("/patient/details")
//	public List<PatientData> getAllPatients();
//
//}
