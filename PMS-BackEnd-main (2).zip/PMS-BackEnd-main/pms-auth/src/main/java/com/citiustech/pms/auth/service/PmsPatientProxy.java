package com.citiustech.pms.auth.service;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.citiustech.pms.auth.model.Demographies;
import com.citiustech.pms.auth.model.PatientData;

import io.swagger.v3.oas.annotations.parameters.RequestBody;

@FeignClient(name="pms-patient")
public interface PmsPatientProxy {
	
	@GetMapping("/patient/getAllPatients")
	public List<Demographies> getAllPatients();
	
	@GetMapping("/patient/getAllBlockedPatients")
	public List<Demographies> getAllBlockedPatients();
	
	@PostMapping("/patient/fetchPatientData")
	public PatientData fetchPatient(@RequestBody String emailId);

	
}
